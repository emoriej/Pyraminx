public class Pyraminx {
    public Face[] faces;  // Four faces in the Pyraminx

    public Pyraminx() {
        faces = new Face[4];

        // Assign colors for each face (e.g., Red, Green, Blue, Yellow)
        faces[0] = new Face("yellow", 0); // Red face
        faces[1] = new Face("green", 1); // Green face
        faces[2] = new Face("blue", 2); // Blue face
        faces[3] = new Face("red", 3); // Yellow face
    }

    public Face getFace(int index) {
        return faces[index];
    }

    public void rotateFace(int faceIndex, boolean clockwise, String layer) {
        if (clockwise) {
            // Rotate the selected face clockwise
            faces[faceIndex].rotateClockwise();
            // Rotate neighboring edges clockwise
            rotateEdgesClockwise(faceIndex, layer);
        } else {
            // Rotate the selected face counterclockwise
            faces[faceIndex].rotateCounterclockwise();
            // Rotate neighboring edges counterclockwise
            rotateEdgesCounterclockwise(faceIndex, layer);
        }
    }

    public void rotateBottomLayer21Clockwise() {
        // Save yellow face's bottom layer
        Piece[] yellowBottomLayer = new Piece[] {
                faces[0].getPiece(1, 0),
        };

        // Move green face's pieces to yellow face
        faces[0].setPiece(1, 0, faces[1].getPiece(4, 0));

        // Move blue face's pieces to green face
        faces[1].setPiece(4, 0, faces[2].getPiece(4, 6));

        // Move yellow face's saved pieces to blue face
        faces[2].setPiece(4, 6, yellowBottomLayer[0]);
    }

    public void rotateBottomLayer22Clockwise() {

        // Save yellow face's bottom layer
        Piece[] yellowBottomLayer = new Piece[] {
                faces[0].getPiece(2, 0),
                faces[0].getPiece(2, 1),
                faces[0].getPiece(2, 2)
        };

        // Move green face's pieces to yellow face
        faces[0].setPiece(2, 0, faces[1].getPiece(4, 2));
        faces[0].setPiece(2, 1, faces[1].getPiece(4, 1));
        faces[0].setPiece(2, 2, faces[1].getPiece(3, 0));

        // Move blue face's pieces to green face
        faces[1].setPiece(4, 2, faces[2].getPiece(3, 4));
        faces[1].setPiece(4, 1, faces[2].getPiece(4, 5));
        faces[1].setPiece(3, 0, faces[2].getPiece(4, 4));

        // Move yellow face's saved pieces to blue face
        faces[2].setPiece(3, 4, yellowBottomLayer[0]);
        faces[2].setPiece(4, 5, yellowBottomLayer[1]);
        faces[2].setPiece(4, 4, yellowBottomLayer[2]);
    }

    public void rotateBottomLayer23Clockwise() {
        Piece[] yellowBottomLayer = new Piece[]{
                faces[0].getPiece(3, 0),
                faces[0].getPiece(3, 1),
                faces[0].getPiece(3, 2),
                faces[0].getPiece(3, 3),
                faces[0].getPiece(3, 4),
        };

        //green to yellow
        faces[0].setPiece(3, 0, faces[1].getPiece(4, 4));
        faces[0].setPiece(3, 1, faces[1].getPiece(4, 3));
        faces[0].setPiece(3, 2, faces[1].getPiece(3, 2));
        faces[0].setPiece(3, 3, faces[1].getPiece(3, 1));
        faces[0].setPiece(3, 4, faces[1].getPiece(2, 0));

        //blue to green
        faces[1].setPiece(4, 4, faces[2].getPiece(2, 2));
        faces[1].setPiece(4, 3, faces[2].getPiece(3, 3));
        faces[1].setPiece(3, 2, faces[2].getPiece(3, 2));
        faces[1].setPiece(3, 1, faces[1].getPiece(4, 3));
        faces[1].setPiece(2, 0, faces[2].getPiece(4, 2));

        //yellow to blue
        faces[2].setPiece(2, 2, yellowBottomLayer[0]);
        faces[2].setPiece(3, 3, yellowBottomLayer[1]);
        faces[2].setPiece(3, 2, yellowBottomLayer[2]);
        faces[2].setPiece(4, 3, yellowBottomLayer[3]);
        faces[2].setPiece(4, 2, yellowBottomLayer[4]);
    }

    public void rotateBottomLayer24Clockwise() {
        Piece[] yellowBottomLayer = new Piece[]{
                faces[0].getPiece(4, 0),
                faces[0].getPiece(4, 1),
                faces[0].getPiece(4, 2),
                faces[0].getPiece(4, 3),
                faces[0].getPiece(4, 4),
                faces[0].getPiece(4, 5),
                faces[0].getPiece(4, 6),
        };

        //green to yellow
        faces[0].setPiece(4, 0, faces[1].getPiece(4, 6));
        faces[0].setPiece(4, 1, faces[1].getPiece(4, 5));
        faces[0].setPiece(4, 2, faces[1].getPiece(3, 4));
        faces[0].setPiece(4, 3, faces[1].getPiece(3, 3));
        faces[0].setPiece(4, 4, faces[1].getPiece(2, 2));
        faces[0].setPiece(4, 5, faces[1].getPiece(2, 1));
        faces[0].setPiece(4, 6, faces[1].getPiece(1, 0));

        //blue to green
        faces[1].setPiece(4, 6, faces[2].getPiece(1, 0));
        faces[1].setPiece(4, 5, faces[2].getPiece(2, 1));
        faces[1].setPiece(3, 4, faces[2].getPiece(2, 0));
        faces[1].setPiece(3, 3, faces[2].getPiece(3, 1));
        faces[1].setPiece(2, 2, faces[2].getPiece(3, 0));
        faces[1].setPiece(2, 1, faces[2].getPiece(4, 1));
        faces[1].setPiece(1, 0, faces[2].getPiece(4, 0));

        //yellow to blue
        faces[2].setPiece(1, 0, yellowBottomLayer[0]);
        faces[2].setPiece(2, 1, yellowBottomLayer[1]);
        faces[2].setPiece(2, 0, yellowBottomLayer[2]);
        faces[2].setPiece(3, 1, yellowBottomLayer[3]);
        faces[2].setPiece(3, 0, yellowBottomLayer[4]);
        faces[2].setPiece(4, 1, yellowBottomLayer[5]);
        faces[2].setPiece(4, 0, yellowBottomLayer[6]);
    }

    public void rotateBottomLayer31Clockwise() {
        // Save yellow face's bottom layer
        Piece[] yellowBottomLayer = new Piece[] {
                faces[0].getPiece(1, 0),
        };

        // Move red to yellow
        faces[0].setPiece(1, 0, faces[3].getPiece(4, 0));

        // Move green to red
        faces[3].setPiece(4, 0, faces[1].getPiece(4, 6));

        // Move yellow to green
        faces[1].setPiece(4, 6, yellowBottomLayer[0]);
    }

    public void rotateBottomLayer32Clockwise() {

        // Save yellow face's bottom layer
        Piece[] yellowBottomLayer = new Piece[] {
                faces[0].getPiece(2, 0),
                faces[0].getPiece(2, 1),
                faces[0].getPiece(2, 2)
        };

        // Move green face's pieces to yellow face
        faces[0].setPiece(2, 0, faces[3].getPiece(4, 2));
        faces[0].setPiece(2, 1, faces[3].getPiece(4, 1));
        faces[0].setPiece(2, 2, faces[3].getPiece(3, 0));

        // Move blue face's pieces to green face
        faces[3].setPiece(4, 2, faces[1].getPiece(3, 4));
        faces[3].setPiece(4, 1, faces[1].getPiece(4, 5));
        faces[3].setPiece(3, 0, faces[1].getPiece(4, 4));

        // Move yellow face's saved pieces to blue face
        faces[1].setPiece(3, 4, yellowBottomLayer[0]);
        faces[1].setPiece(4, 5, yellowBottomLayer[1]);
        faces[1].setPiece(4, 4, yellowBottomLayer[2]);
    }

    public void rotateBottomLayer33Clockwise() {
        Piece[] yellowBottomLayer = new Piece[]{
                faces[0].getPiece(3, 0),
                faces[0].getPiece(3, 1),
                faces[0].getPiece(3, 2),
                faces[0].getPiece(3, 3),
                faces[0].getPiece(3, 4),
        };

        //green to yellow
        faces[0].setPiece(3, 0, faces[3].getPiece(4, 4));
        faces[0].setPiece(3, 1, faces[3].getPiece(4, 3));
        faces[0].setPiece(3, 2, faces[3].getPiece(3, 2));
        faces[0].setPiece(3, 3, faces[3].getPiece(3, 1));
        faces[0].setPiece(3, 4, faces[3].getPiece(2, 0));

        //blue to green
        faces[3].setPiece(4, 4, faces[1].getPiece(2, 2));
        faces[3].setPiece(4, 3, faces[1].getPiece(3, 3));
        faces[3].setPiece(3, 2, faces[1].getPiece(3, 2));
        faces[3].setPiece(3, 1, faces[1].getPiece(4, 3));
        faces[3].setPiece(2, 0, faces[1].getPiece(4, 2));

        //yellow to blue
        faces[1].setPiece(2, 2, yellowBottomLayer[0]);
        faces[1].setPiece(3, 3, yellowBottomLayer[1]);
        faces[1].setPiece(3, 2, yellowBottomLayer[2]);
        faces[1].setPiece(4, 3, yellowBottomLayer[3]);
        faces[1].setPiece(4, 2, yellowBottomLayer[4]);
    }

    public void rotateBottomLayer34Clockwise() {
        Piece[] yellowBottomLayer = new Piece[]{
                faces[0].getPiece(4, 0),
                faces[0].getPiece(4, 1),
                faces[0].getPiece(4, 2),
                faces[0].getPiece(4, 3),
                faces[0].getPiece(4, 4),
                faces[0].getPiece(4, 5),
                faces[0].getPiece(4, 6),
        };

        //green to yellow
        faces[0].setPiece(4, 0, faces[3].getPiece(4, 6));
        faces[0].setPiece(4, 1, faces[3].getPiece(4, 5));
        faces[0].setPiece(4, 2, faces[3].getPiece(3, 4));
        faces[0].setPiece(4, 3, faces[3].getPiece(3, 3));
        faces[0].setPiece(4, 4, faces[3].getPiece(2, 2));
        faces[0].setPiece(4, 5, faces[3].getPiece(2, 1));
        faces[0].setPiece(4, 6, faces[3].getPiece(1, 0));

        //blue to green
        faces[3].setPiece(4, 6, faces[1].getPiece(1, 0));
        faces[3].setPiece(4, 5, faces[1].getPiece(2, 1));
        faces[3].setPiece(3, 4, faces[1].getPiece(2, 0));
        faces[3].setPiece(3, 3, faces[1].getPiece(3, 1));
        faces[3].setPiece(2, 2, faces[1].getPiece(3, 0));
        faces[3].setPiece(2, 1, faces[1].getPiece(4, 1));
        faces[3].setPiece(1, 0, faces[1].getPiece(4, 0));

        //yellow to blue
        faces[1].setPiece(1, 0, yellowBottomLayer[0]);
        faces[1].setPiece(2, 1, yellowBottomLayer[1]);
        faces[1].setPiece(2, 0, yellowBottomLayer[2]);
        faces[1].setPiece(3, 1, yellowBottomLayer[3]);
        faces[1].setPiece(3, 0, yellowBottomLayer[4]);
        faces[1].setPiece(4, 1, yellowBottomLayer[5]);
        faces[1].setPiece(4, 0, yellowBottomLayer[6]);
    }

    public void rotateBottomLayer41Clockwise() {
        // Save yellow face's bottom layer
        Piece[] yellowBottomLayer = new Piece[] {
                faces[0].getPiece(1, 0),
        };

        // Move blue to yellow
        faces[0].setPiece(1, 0, faces[2].getPiece(4, 0));

        // Move red to blue
        faces[2].setPiece(4, 0, faces[3].getPiece(4, 6));

        // Move yellow to red
        faces[3].setPiece(4, 6, yellowBottomLayer[0]);
    }

    public void rotateBottomLayer42Clockwise() {

        // Save yellow face's bottom layer
        Piece[] yellowBottomLayer = new Piece[] {
                faces[0].getPiece(2, 0),
                faces[0].getPiece(2, 1),
                faces[0].getPiece(2, 2)
        };

        // Move green face's pieces to yellow face
        faces[0].setPiece(2, 0, faces[2].getPiece(4, 2));
        faces[0].setPiece(2, 1, faces[2].getPiece(4, 1));
        faces[0].setPiece(2, 2, faces[2].getPiece(3, 0));

        // Move blue face's pieces to green face
        faces[2].setPiece(4, 2, faces[3].getPiece(3, 4));
        faces[2].setPiece(4, 1, faces[3].getPiece(4, 5));
        faces[2].setPiece(3, 0, faces[3].getPiece(4, 4));

        // Move yellow face's saved pieces to blue face
        faces[3].setPiece(3, 4, yellowBottomLayer[0]);
        faces[3].setPiece(4, 5, yellowBottomLayer[1]);
        faces[3].setPiece(4, 4, yellowBottomLayer[2]);
    }

    public void rotateBottomLayer43Clockwise() {
        Piece[] yellowBottomLayer = new Piece[]{
                faces[0].getPiece(3, 0),
                faces[0].getPiece(3, 1),
                faces[0].getPiece(3, 2),
                faces[0].getPiece(3, 3),
                faces[0].getPiece(3, 4),
        };

        //green to yellow
        faces[0].setPiece(3, 0, faces[2].getPiece(4, 4));
        faces[0].setPiece(3, 1, faces[2].getPiece(4, 3));
        faces[0].setPiece(3, 2, faces[2].getPiece(3, 2));
        faces[0].setPiece(3, 3, faces[2].getPiece(3, 1));
        faces[0].setPiece(3, 4, faces[2].getPiece(2, 0));

        //blue to green
        faces[2].setPiece(4, 4, faces[3].getPiece(2, 2));
        faces[2].setPiece(4, 3, faces[3].getPiece(3, 3));
        faces[2].setPiece(3, 2, faces[3].getPiece(3, 2));
        faces[2].setPiece(3, 1, faces[3].getPiece(4, 3));
        faces[2].setPiece(2, 0, faces[3].getPiece(4, 2));

        //yellow to blue
        faces[3].setPiece(2, 2, yellowBottomLayer[0]);
        faces[3].setPiece(3, 3, yellowBottomLayer[1]);
        faces[3].setPiece(3, 2, yellowBottomLayer[2]);
        faces[3].setPiece(4, 3, yellowBottomLayer[3]);
        faces[3].setPiece(4, 2, yellowBottomLayer[4]);
    }

    public void rotateBottomLayer44Clockwise() {
        Piece[] yellowBottomLayer = new Piece[]{
                faces[0].getPiece(4, 0),
                faces[0].getPiece(4, 1),
                faces[0].getPiece(4, 2),
                faces[0].getPiece(4, 3),
                faces[0].getPiece(4, 4),
                faces[0].getPiece(4, 5),
                faces[0].getPiece(4, 6),
        };

        //green to yellow
        faces[0].setPiece(4, 0, faces[2].getPiece(4, 6));
        faces[0].setPiece(4, 1, faces[2].getPiece(4, 5));
        faces[0].setPiece(4, 2, faces[2].getPiece(3, 4));
        faces[0].setPiece(4, 3, faces[2].getPiece(3, 3));
        faces[0].setPiece(4, 4, faces[2].getPiece(2, 2));
        faces[0].setPiece(4, 5, faces[2].getPiece(2, 1));
        faces[0].setPiece(4, 6, faces[2].getPiece(1, 0));

        //blue to green
        faces[2].setPiece(4, 6, faces[3].getPiece(1, 0));
        faces[2].setPiece(4, 5, faces[3].getPiece(2, 1));
        faces[2].setPiece(3, 4, faces[3].getPiece(2, 0));
        faces[2].setPiece(3, 3, faces[3].getPiece(3, 1));
        faces[2].setPiece(2, 2, faces[3].getPiece(3, 0));
        faces[2].setPiece(2, 1, faces[3].getPiece(4, 1));
        faces[2].setPiece(1, 0, faces[3].getPiece(4, 0));

        //yellow to blue
        faces[3].setPiece(1, 0, yellowBottomLayer[0]);
        faces[3].setPiece(2, 1, yellowBottomLayer[1]);
        faces[3].setPiece(2, 0, yellowBottomLayer[2]);
        faces[3].setPiece(3, 1, yellowBottomLayer[3]);
        faces[3].setPiece(3, 0, yellowBottomLayer[4]);
        faces[3].setPiece(4, 1, yellowBottomLayer[5]);
        faces[3].setPiece(4, 0, yellowBottomLayer[6]);
    }

    private void printFaceState(Face face) {
        Piece[][] pieces = face.getPieces();
        for (int row = 0; row < pieces.length; row++) {
            for (Piece piece : pieces[row]) {
                System.out.print(piece + " ");
            }
            System.out.println();
        }
        System.out.println();
    }

    // Helper function to get a diagonal layer from a face
    private Piece[] getDiagonalLayer(Face face, int layer) {
        return face.getLayer(layer);
    }

    // Helper function to set a diagonal layer on a face
    private void setDiagonalLayer(Face face, int layer, Piece[] pieces) {
        face.setLayer(layer, pieces);
    }

    // Rotating neighboring edges clockwise
    private void rotateEdgesClockwise(int faceIndex, String position) {
        Piece[] temp = getEdge(faces[1], position);
        setEdge(faces[1], position, getEdge(faces[2], position));
        setEdge(faces[2], position, getEdge(faces[3], position));
        setEdge(faces[3], position, temp);
    }

    // Rotating neighboring edges counterclockwise
    private void rotateEdgesCounterclockwise(int faceIndex, String position) {
        // Similar to rotateEdgesClockwise but in reverse
        Piece[] temp = getEdge(faces[1], position);
        setEdge(faces[1], position, getEdge(faces[3], position));
        setEdge(faces[3], position, getEdge(faces[2], position));
        setEdge(faces[2], position, temp);
    }

    private Piece[] getEdge(Face face, String position) {
        switch (position) {
            case "top":
                return face.getPieces()[0];  // Top row of the face
            case "second":
                return face.getPieces()[1];
            case "third":
                return face.getPieces()[2];
            case "bottom":
                return face.getPieces()[3];  // Bottom row of the face
            default:
                return null;
        }
    }

    private void setEdge(Face face, String position, Piece[] edgePieces) {
        switch (position) {
            case "top":
                face.getPieces()[0] = edgePieces;  // Set top row
                break;
            case "second":
                face.getPieces()[1] = edgePieces;
                break;
            case "third":
                face.getPieces()[2] = edgePieces;
                break;
            case "bottom":
                face.getPieces()[3] = edgePieces;
                break;
            default:
                face.getPieces()[0] = edgePieces;
                break;
        }
    }
}
