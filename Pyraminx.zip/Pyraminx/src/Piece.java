public class Piece {
    private String color;
    private int originalRow;
    private int originalCol;
    private int originalFace;

    public Piece(String color, int originalFace, int originalRow, int originalCol) {
        this.color = color;
        this.originalFace = originalFace;  // The face the piece originated from
        this.originalRow = originalRow;    // The row the piece originated from
        this.originalCol = originalCol;    // The column the piece originated from
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getOriginalRow() {
        return originalRow;
    }

    public int getOriginalCol() {
        return originalCol;
    }

    public int getOriginalFace() {
        return originalFace;
    }

    public String toString() {
        return "Piece[Color=" + color + ", Face=" + originalFace + ", Row=" + originalRow + ", Col=" + originalCol + "]";
    }
}
