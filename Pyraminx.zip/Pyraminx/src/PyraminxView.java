import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;

public class PyraminxView extends Pane {
    public Pyraminx pyraminx;

    public PyraminxView() {
        pyraminx = new Pyraminx();

        renderFace(pyraminx.getFace(0), 260, 300);
        renderFace(pyraminx.getFace(1), 50, 100);
        renderFace(pyraminx.getFace(2), 260, 100);
        renderFace(pyraminx.getFace(3), 470, 100);
    }

    void renderFace(Face face, double startX, double startY) {
        Piece[][] pieces = face.getPieces();
        double sideLength = 50;  // Side length for each triangle

        for (int row = 0; row < pieces.length; row++) {
            // Calculate the X offset for each row to align the pieces into a perfect triangle
            double rowOffset = (3 - row) * (sideLength / 2);

            for (int col = 0; col < pieces[row].length; col++) {
                Piece piece = pieces[row][col];

                // Proceed only if the piece is not null
                if (piece != null) {
                    // Calculate the coordinates of the triangle based on row and column
                    double[] coordinates;
                    if (col % 2 == 0) {
                        // Right-side-up triangle
                        coordinates = calculateUpsideDownTriangle(row, col, startX + rowOffset, startY, sideLength);
                    } else {
                        // Upside-down triangle
                        coordinates = calculateRightSideUpTriangle(row, col, startX + rowOffset, startY, sideLength);
                    }

                    // Create the triangle shape
                    Polygon triangle = new Polygon(coordinates);
                    triangle.setFill(Color.web(piece.getColor()));  // Set color of the piece

                    // Add border to the triangle
                    triangle.setStroke(Color.BLACK);  // Set border color (e.g., black)
                    triangle.setStrokeWidth(2);       // Set border width

                    // Add the triangle to the Pane
                    getChildren().add(triangle);
                }
            }
        }
    }



    // Right-side-up triangle
    private double[] calculateRightSideUpTriangle(int row, int col, double startX, double startY, double sideLength) {
        double x1 = startX + col * sideLength / 2;
        double y1 = startY + row * (sideLength * Math.sqrt(3) / 2);
        double x2 = x1 + sideLength;
        double y2 = y1;
        double x3 = x1 + sideLength / 2;
        double y3 = y1 + (Math.sqrt(3) / 2) * sideLength;

        return new double[]{x1, y1, x2, y2, x3, y3};
    }

    // Upside-down triangle
    private double[] calculateUpsideDownTriangle(int row, int col, double startX, double startY, double sideLength) {
        double x1 = startX + col * sideLength / 2;
        double y1 = startY + row * (sideLength * Math.sqrt(3) / 2) + (Math.sqrt(3) / 2) * sideLength;
        double x2 = x1 + sideLength;
        double y2 = y1;
        double x3 = x1 + sideLength / 2;
        double y3 = y1 - (Math.sqrt(3) / 2) * sideLength;

        return new double[]{x1, y1, x2, y2, x3, y3};
    }
}
