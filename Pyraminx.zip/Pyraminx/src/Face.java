public class Face {
    private Piece[][] pieces;

    public Face(String color, int index) {
        // Initialize a 4x4 face with different pieces
        pieces = new Piece[4][];
        pieces[0] = new Piece[1];  // Top row has 1 piece
        pieces[1] = new Piece[3];  // Second row has 3 pieces
        pieces[2] = new Piece[5];  // Third row has 5 pieces
        pieces[3] = new Piece[7];  // Fourth row has 7 pieces

        // Initialize each piece with the face's color
        for (int row = 0; row < pieces.length; row++) {
            for (int col = 0; col < pieces[row].length; col++) {
                pieces[row][col] = new Piece(color, index, row, col);  // Initialize with the provided color
            }
        }
    }

    public Piece[][] getPieces() {
        return pieces;
    }

    // Get a specific layer of pieces
    public Piece[] getLayer(int layer) {
        return pieces[layer - 1];  // layer is 1-indexed, so subtract 1
    }

    // Set a specific layer of pieces
    public void setLayer(int layer, Piece[] newLayer) {
        pieces[layer - 1] = newLayer;
    }

    // Rotate the face clockwise
    public void rotateClockwise() {
        // Step 1: Rotate the top layer (1 piece)
        rotateArrayClockwise(pieces[0]);

        // Step 2: Rotate the second layer (3 pieces)
        rotateArrayClockwise(pieces[1]);

        // Step 3: Rotate the third layer (5 pieces)
        rotateArrayClockwise(pieces[2]);

        // Step 4: Rotate the fourth layer (7 pieces)
        rotateArrayClockwise(pieces[3]);
    }


    // Rotate the face counterclockwise
    public void rotateCounterclockwise() {
        // Step 1: Rotate the top layer (1 piece) counterclockwise
        rotateArrayCounterclockwise(pieces[0]);

        // Step 2: Rotate the second layer (3 pieces) counterclockwise
        rotateArrayCounterclockwise(pieces[1]);

        // Step 3: Rotate the third layer (5 pieces) counterclockwise
        rotateArrayCounterclockwise(pieces[2]);

        // Step 4: Rotate the fourth layer (7 pieces) counterclockwise
        rotateArrayCounterclockwise(pieces[3]);
    }

    // Helper method to rotate an array of pieces clockwise
    private void rotateArrayClockwise(Piece[] row) {
        if (row.length > 1) {
            Piece temp = row[row.length - 1];  // Save the last element
            System.arraycopy(row, 0, row, 1, row.length - 1);  // Shift all elements right
            row[0] = temp;  // Move the saved last element to the first position
        }
    }

    // Helper method to rotate an array of pieces counterclockwise
    private void rotateArrayCounterclockwise(Piece[] row) {
        if (row.length > 1) {
            Piece temp = row[0];  // Save the first element
            System.arraycopy(row, 1, row, 0, row.length - 1);  // Shift all elements left
            row[row.length - 1] = temp;  // Move the saved first element to the last position
        }
    }

    public Piece getPiece(int layer, int col) {
        return pieces[layer - 1][col];
    }

    public void setPiece(int layer, int i, Piece piece) {
        pieces[layer - 1][i] = piece;
    }
}

