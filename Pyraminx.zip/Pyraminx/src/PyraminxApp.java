import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import java.util.*;

import static javafx.geometry.Pos.CENTER;

public class PyraminxApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create the PyraminxView object (the main view of the puzzle)
        PyraminxView pyraminxView = new PyraminxView();

        // Create a button to rotate layers
        Button rotateLayer1_1Button = new Button("Rotate Layer 1.1");
        Button rotateLayer1_2Button = new Button("Rotate Layer 1.2");
        Button rotateLayer1_3Button = new Button("Rotate Layer 1.3");
        Button rotateLayer1_4Button = new Button("Rotate Layer 1.4");

        Button rotateLayer2_1Button = new Button("Rotate Layer 2.1");
        Button rotateLayer2_2Button = new Button("Rotate Layer 2.2");
        Button rotateLayer2_3Button = new Button("Rotate Layer 2.3");
        Button rotateLayer2_4Button = new Button("Rotate Layer 2.4");

        Button rotateLayer3_1Button = new Button("Rotate Layer 3.1");
        Button rotateLayer3_2Button = new Button("Rotate Layer 3.2");
        Button rotateLayer3_3Button = new Button("Rotate Layer 3.3");
        Button rotateLayer3_4Button = new Button("Rotate Layer 3.4");

        Button rotateLayer4_1Button = new Button("Rotate Layer 4.1");
        Button rotateLayer4_2Button = new Button("Rotate Layer 4.2");
        Button rotateLayer4_3Button = new Button("Rotate Layer 4.3");
        Button rotateLayer4_4Button = new Button("Rotate Layer 4.4");

        rotateLayer1_1Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                pyraminxView.pyraminx.rotateFace(0, true, "top");  // Rotate face 0 (Layer 1) clockwise
                pyraminxView.getChildren().clear();  // Clear the current rendering
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(0), 260, 300);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(1), 50, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(2), 260, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(3), 470, 100);
            }
        });

        rotateLayer1_2Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                pyraminxView.pyraminx.rotateFace(0, true, "second");  // Rotate face 0 (Layer 2) clockwise
                pyraminxView.getChildren().clear();  // Clear the current rendering
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(0), 260, 300);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(1), 50, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(2), 260, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(3), 470, 100);
            }
        });

        rotateLayer1_3Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                pyraminxView.pyraminx.rotateFace(0, true, "third");  // Rotate face 0 (Layer 3) clockwise
                pyraminxView.getChildren().clear();  // Clear the current rendering
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(0), 260, 300);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(1), 50, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(2), 260, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(3), 470, 100);
            }
        });

        rotateLayer1_4Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                pyraminxView.pyraminx.rotateFace(0, true, "bottom");  // Rotate face 0 (Layer 4) clockwise
                pyraminxView.getChildren().clear();  // Clear the current rendering
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(0), 260, 300);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(1), 50, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(2), 260, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(3), 470, 100);
            }
        });

        rotateLayer2_1Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                pyraminxView.pyraminx.rotateBottomLayer21Clockwise();  // Rotate face 0 (Layer 2) clockwise
                pyraminxView.getChildren().clear();  // Clear the current rendering
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(0), 260, 300);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(1), 50, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(2), 260, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(3), 470, 100);
            }
        });

        rotateLayer2_2Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                pyraminxView.pyraminx.rotateBottomLayer22Clockwise();  // Rotate face 0 (Layer 2) clockwise
                pyraminxView.getChildren().clear();  // Clear the current rendering
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(0), 260, 300);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(1), 50, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(2), 260, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(3), 470, 100);
            }
        });

        rotateLayer2_3Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                pyraminxView.pyraminx.rotateBottomLayer23Clockwise();  // Rotate face 0 (Layer 2) clockwise
                pyraminxView.getChildren().clear();  // Clear the current rendering
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(0), 260, 300);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(1), 50, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(2), 260, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(3), 470, 100);
            }
        });

        rotateLayer2_4Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                pyraminxView.pyraminx.rotateBottomLayer24Clockwise();  // Rotate face 0 (Layer 2) clockwise
                pyraminxView.getChildren().clear();  // Clear the current rendering
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(0), 260, 300);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(1), 50, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(2), 260, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(3), 470, 100);
            }
        });

        rotateLayer3_1Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                pyraminxView.pyraminx.rotateBottomLayer31Clockwise();  // Rotate face 0 (Layer 2) clockwise
                pyraminxView.getChildren().clear();  // Clear the current rendering
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(0), 260, 300);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(1), 50, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(2), 260, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(3), 470, 100);
            }
        });

        rotateLayer3_2Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                pyraminxView.pyraminx.rotateBottomLayer32Clockwise();  // Rotate face 0 (Layer 2) clockwise
                pyraminxView.getChildren().clear();  // Clear the current rendering
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(0), 260, 300);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(1), 50, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(2), 260, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(3), 470, 100);
            }
        });

        rotateLayer3_3Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                pyraminxView.pyraminx.rotateBottomLayer33Clockwise();  // Rotate face 0 (Layer 2) clockwise
                pyraminxView.getChildren().clear();  // Clear the current rendering
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(0), 260, 300);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(1), 50, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(2), 260, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(3), 470, 100);
            }
        });

        rotateLayer3_4Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                pyraminxView.pyraminx.rotateBottomLayer34Clockwise();  // Rotate face 0 (Layer 2) clockwise
                pyraminxView.getChildren().clear();  // Clear the current rendering
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(0), 260, 300);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(1), 50, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(2), 260, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(3), 470, 100);
            }
        });

        rotateLayer4_1Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                pyraminxView.pyraminx.rotateBottomLayer41Clockwise();  // Rotate face 0 (Layer 2) clockwise
                pyraminxView.getChildren().clear();  // Clear the current rendering
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(0), 260, 300);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(1), 50, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(2), 260, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(3), 470, 100);
            }
        });

        rotateLayer4_2Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                pyraminxView.pyraminx.rotateBottomLayer42Clockwise();  // Rotate face 0 (Layer 2) clockwise
                pyraminxView.getChildren().clear();  // Clear the current rendering
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(0), 260, 300);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(1), 50, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(2), 260, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(3), 470, 100);
            }
        });

        rotateLayer4_3Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                pyraminxView.pyraminx.rotateBottomLayer43Clockwise();  // Rotate face 0 (Layer 2) clockwise
                pyraminxView.getChildren().clear();  // Clear the current rendering
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(0), 260, 300);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(1), 50, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(2), 260, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(3), 470, 100);
            }
        });

        rotateLayer4_4Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                pyraminxView.pyraminx.rotateBottomLayer44Clockwise();  // Rotate face 0 (Layer 2) clockwise
                pyraminxView.getChildren().clear();  // Clear the current rendering
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(0), 260, 300);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(1), 50, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(2), 260, 100);
                pyraminxView.renderFace(pyraminxView.pyraminx.getFace(3), 470, 100);
            }
        });

        VBox buttonBox = new VBox(10);
        buttonBox.getChildren().addAll(rotateLayer1_1Button, rotateLayer1_2Button, rotateLayer1_3Button, rotateLayer1_4Button,
                rotateLayer2_1Button, rotateLayer2_2Button, rotateLayer2_3Button, rotateLayer2_4Button,
                rotateLayer3_1Button, rotateLayer3_2Button, rotateLayer3_3Button, rotateLayer3_4Button,
                rotateLayer4_1Button, rotateLayer4_2Button, rotateLayer4_3Button, rotateLayer4_4Button);
        buttonBox.setLayoutX(700);
        buttonBox.setLayoutY(200);

        Label resultLabel = new Label();
        TextField randomNumber = new TextField();
        randomNumber.setPromptText("Please enter an integer");
        Button submitButton = new Button("Submit");


        randomNumber.setAlignment(CENTER);
        randomNumber.setLayoutY(10);

        submitButton.setOnAction(event -> {
            try {
                // Get the text from the TextField and parse it as an integer
                int userInput = Integer.parseInt(randomNumber.getText());
                Random random = new Random();
                for (int i = 0; i < userInput;i++){
                    int randomInt = random.nextInt(16)+1;
                    System.out.println("Random move generated: " + randomInt);
                    switch (randomInt){
                        case 1:
                            rotateLayer1_1Button.fire();
                            break;
                        case 2:
                            rotateLayer1_2Button.fire();
                            break;
                        case 3:
                            rotateLayer1_3Button.fire();
                            break;
                        case 4:
                            rotateLayer1_4Button.fire();
                            break;
                        case 5:
                            rotateLayer2_1Button.fire();
                            break;
                        case 6:
                            rotateLayer2_2Button.fire();
                            break;
                        case 7:
                            rotateLayer2_3Button.fire();
                            break;
                        case 8:
                            rotateLayer2_4Button.fire();
                            break;
                        case 9:
                            rotateLayer3_1Button.fire();
                            break;
                        case 10:
                            rotateLayer3_2Button.fire();
                            break;
                        case 11:
                            rotateLayer3_3Button.fire();
                            break;
                        case 12:
                            rotateLayer3_4Button.fire();
                            break;
                        case 13:
                            rotateLayer4_1Button.fire();
                            break;
                        case 14:
                            rotateLayer4_2Button.fire();
                            break;
                        case 15:
                            rotateLayer4_3Button.fire();
                            break;
                        case 16:
                            rotateLayer4_4Button.fire();
                            break;
                        default:
                            rotateLayer1_1Button.fire();
                            break;

                    }
                }
            } catch (NumberFormatException e) {
                // Handle the case where the input is not a valid integer
                resultLabel.setText("Please enter a valid integer.");
            } catch (Exception e) {
                e.printStackTrace();  // Log any unexpected errors
                resultLabel.setText("An error occurred.");
            }
        });

        VBox input = new VBox(10);
        input.getChildren().addAll(randomNumber, submitButton, resultLabel);
        input.setLayoutX(700);
        input.setLayoutY(100);

        // Create a root Pane and add PyraminxView and the button to it
        Pane root = new Pane();
        root.getChildren().addAll(input, pyraminxView, buttonBox);

        // Create a scene, with the root Pane as the root node
        Scene scene = new Scene(root, 800, 600);

        // Set the scene for the stage
        primaryStage.setTitle("Pyraminx Puzzle");
        primaryStage.setScene(scene);
        primaryStage.show();  // Ensure this is called to show the window
    }

    public static void main(String[] args) {
        launch(args);
    }
}


